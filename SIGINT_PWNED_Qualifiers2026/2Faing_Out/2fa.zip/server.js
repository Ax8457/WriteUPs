const express = require('express');
const session = require('express-session');
const cors = require('cors');

const crypto = require("crypto");
const app = express();

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));
app.use(express.json())
app.use(express.static('public'));
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
    credentials: true
}));

app.use((req, res, next) => {
    res.set("Content-Security-Policy", "default-src 'self' 'unsafe-inline'; connect-src 'self';");
    next();
})

app.use(session({
    secret: crypto.randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true }
}));

const SECRET_KEY = crypto.randomBytes(32).toString('hex')
const users = [
    {
        username: 'admin',
        password: process.env.ADMIN_PASSWORD,
        email: 'admin@example.com',
        resetToken: null
    },
    {
        username: 'attacker',
        password: 'attacker',
        email: 'attacker@example.com',
        resetToken: null
    }
];

const redirectLogin = (req, res, next) => {
    if (!req.session.userId) {
        res.redirect('/login');
    } else {
        next();
    }
};

app.get('/', (req, res) => {
    res.render("index", { userId: req.session.userId });
});

app.get('/login', (req, res) => {
    res.render("login")
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log("Login attempt:", username);
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        req.session.userId = user.username;
        console.log("Log in succeeded");
        return res.redirect('/dashboard');
    }
    res.redirect('/login');
});

app.get('/dashboard', redirectLogin, (req, res) => {
    if (req.session.userId === 'admin') {
        return res.send(`Welcome Admin! We are sorry for the bad css, but here is your flag reminder: ${process.env.FLAG || 'PWNED{FAKE_FLAG}'}`);
    }
    res.render("dashboard", { user: req.session.userId })
});

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        res.clearCookie('connect.sid');
        res.redirect('/');
    });
});

app.get('/forgot-password', (_req, res) => {
    res.render('forgot-password');
});

app.post('/forgot-password', (req, res) => {
    const { email } = req.body;
    const user = users.find(u => u.email === email);

    if (!user) {
        return res.status(401).send("You must be logged in.");
    }

    const token = crypto.createHash('sha256')
        .update((Date.now() >> 3).toString() + SECRET_KEY)
        .digest('hex');

    user.resetToken = token;

    res.send(`Token generated! <a href="/reset">Click here to reset password</a>`);
});

app.get('/reset', (req, res) => {
    const user = users.find(u => u.username === req.session.userId);

    if (!user || !user.resetToken) {
        return res.status(403).send("No reset token found for this account.");
    }

    res.render("reset", { username: user.username, token: user.resetToken});
});

app.post('/reset', (req, res) => {
    const { username, newPassword, resetToken} = req.body;

    const currentUser = users.find(u => u.username === username && u.resetToken === resetToken);

    if (currentUser) {
        console.log(`Resetting ${currentUser.username} password`);
        currentUser.password = newPassword;
        currentUser.resetToken = null;
        return res.redirect('/dashboard');
    }

    res.status(403).send("Error updating password: No valid reset session found.");
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
})
